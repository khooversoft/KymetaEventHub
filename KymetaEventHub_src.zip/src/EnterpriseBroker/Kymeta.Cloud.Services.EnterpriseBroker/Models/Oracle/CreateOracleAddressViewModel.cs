﻿namespace Kymeta.Cloud.Services.EnterpriseBroker.Models.Oracle;

public class CreateOracleAddressViewModel
{
    public string Address1 { get; set; }
    public string Address2 { get; set; }
    public string Country { get; set; }
}
