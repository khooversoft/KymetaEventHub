﻿namespace Kymeta.Cloud.Services.EnterpriseBroker.Models.Oracle;

public class OracleAddressObject
{
    public string PartyNumber { get; set; }
    public string Address1 { get; set; }
}
