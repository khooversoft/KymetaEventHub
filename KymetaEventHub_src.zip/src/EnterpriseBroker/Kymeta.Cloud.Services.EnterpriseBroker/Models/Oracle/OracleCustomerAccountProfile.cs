﻿namespace Kymeta.Cloud.Services.EnterpriseBroker.Models.Oracle
{
    public class OracleCustomerAccountProfile
    {
        public ulong? PartyId { get; set; }
    }
}
