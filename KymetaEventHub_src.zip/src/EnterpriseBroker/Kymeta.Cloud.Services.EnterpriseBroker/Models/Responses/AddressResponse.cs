﻿namespace Kymeta.Cloud.Services.EnterpriseBroker.Models.Responses
{
    public class AddressResponse : SalesforceProcessResponse
    {
        public string? OracleAddressId { get; set; }
    }
}
