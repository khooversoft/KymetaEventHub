﻿namespace Kymeta.Cloud.Services.EnterpriseBroker.Models.Responses
{
    public class ContactResponse : SalesforceProcessResponse
    {
        public string? OraclePersonId { get; set; }
    }
}
