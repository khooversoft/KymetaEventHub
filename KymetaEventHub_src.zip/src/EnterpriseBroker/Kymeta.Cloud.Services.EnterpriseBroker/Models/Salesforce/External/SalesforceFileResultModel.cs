﻿namespace Kymeta.Cloud.Services.EnterpriseBroker.Models.Salesforce.External
{
    public class SalesforceFileResultModel
    {
        public SalesforceFileObjectModel? Result { get; set; }
        public int StatusCode { get; set; }
    }
}
