﻿namespace Kymeta.Cloud.Services.EnterpriseBroker.Models.Salesforce.External
{
    public class SalesforceQueryRelatedFilesModel
    {
        public string Id { get; set; }
        public string LinkedEntityId { get; set; }
        public string ContentDocumentId { get; set; }
    }
}
