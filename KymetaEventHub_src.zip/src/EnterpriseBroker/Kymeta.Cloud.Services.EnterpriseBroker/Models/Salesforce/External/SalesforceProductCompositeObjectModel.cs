﻿namespace Kymeta.Cloud.Services.EnterpriseBroker.Models.Salesforce.External
{
    public class SalesforceProductCompositeObjectModel
    {
        public List<string> Ids { get; set; }
        public List<string> Fields { get; set; }
    }
}
