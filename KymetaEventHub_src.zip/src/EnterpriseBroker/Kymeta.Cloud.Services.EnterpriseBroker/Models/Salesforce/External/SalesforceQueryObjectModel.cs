﻿namespace Kymeta.Cloud.Services.EnterpriseBroker.Models.Salesforce.External;

public class SalesforceQueryObjectModel<T>
{
    public List<T> Records { get; set; }
}
