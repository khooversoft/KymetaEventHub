﻿namespace Kymeta.Cloud.Services.EnterpriseBroker.Models.Salesforce
{
    public class UpdateContactModel : SalesforceActionObject
    {
    }
}
